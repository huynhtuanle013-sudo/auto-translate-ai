import os
import json
import time
import uuid
import hashlib
import base64
import threading
import re
import subprocess
from datetime import datetime
from urllib.parse import urlencode
from werkzeug.utils import secure_filename

from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for
from flask_socketio import SocketIO, emit
from flask_cors import CORS
import requests

# ==================== CONFIG ====================
class Config:
    TEMP_FOLDER = 'temp/'
    VIDEO_FOLDER = os.path.join(TEMP_FOLDER, 'videos/')
    AUDIO_FOLDER = os.path.join(TEMP_FOLDER, 'audio/')
    SUBTITLE_FOLDER = os.path.join(TEMP_FOLDER, 'subtitles/')
    EXPORT_FOLDER = os.path.join(TEMP_FOLDER, 'exports/')
    PRESET_FOLDER = os.path.join(TEMP_FOLDER, 'presets/')
    UPLOAD_FOLDER = os.path.join(TEMP_FOLDER, 'uploads/')
    
    LANGUAGES = {
        'vi': 'Tiếng Việt', 'en': 'Tiếng Anh', 'zh': 'Tiếng Trung',
        'ja': 'Tiếng Nhật', 'ko': 'Tiếng Hàn', 'fr': 'Tiếng Pháp',
        'de': 'Tiếng Đức', 'es': 'Tiếng Tây Ban Nha', 'th': 'Tiếng Thái',
        'id': 'Tiếng Indonesia', 'pt': 'Tiếng Bồ Đào Nha', 'ru': 'Tiếng Nga',
        'ar': 'Tiếng Ả Rập', 'hi': 'Tiếng Hindi', 'it': 'Tiếng Ý',
        'nl': 'Tiếng Hà Lan', 'pl': 'Tiếng Ba Lan', 'tr': 'Tiếng Thổ Nhĩ Kỳ',
        'ms': 'Tiếng Malaysia', 'fil': 'Tiếng Filipino'
    }
    
    ALLOWED_VIDEO_EXT = {'mp4', 'avi', 'mov', 'mkv', 'webm', 'flv', 'm4v'}
    ALLOWED_AUDIO_EXT = {'mp3', 'wav', 'm4a', 'aac', 'flac', 'ogg'}
    ALLOWED_SUBTITLE_EXT = {'srt', 'vtt', 'ass'}
    ALLOWED_EXTENSIONS = ALLOWED_VIDEO_EXT | ALLOWED_AUDIO_EXT | ALLOWED_SUBTITLE_EXT
    
    MAX_FILE_SIZE = 500 * 1024 * 1024
    
    FONTS = ['Arial', 'Helvetica', 'Oswald', 'Roboto', 'Open Sans', 'Montserrat', 'Inter']
    SUBTITLE_COLORS = ['#FFFFFF', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF']
    BLUR_MODES = ['Mặc định', 'Vùng lân cận']
    LOGO_POSITIONS = ['Góc trên - Trái', 'Góc trên - Phải', 'Góc dưới - Trái', 'Góc dưới - Phải', 'Giữa']
    
    TRANSLATION_STYLES = {
        'default': {'name': 'Mặc định', 'icon': '📝', 'prompt': 'Dịch chuẩn xác, trung lập.'},
        'review_phim': {'name': 'Review Phim', 'icon': '🎬', 'prompt': 'Dịch li kỳ, lôi cuốn, bám sát.'},
        'ngan_gon': {'name': 'Dịch ngắn gọn', 'icon': '✂️', 'prompt': 'Dịch cô đọng, súc tích.'},
        'gioi_tre': {'name': 'Ngôn ngữ giới trẻ', 'icon': '🔥', 'prompt': 'Dịch hài hước, bắt trend.'},
        'tong_tai': {'name': 'Tổng Tài / Ngôn Tình', 'icon': '💎', 'prompt': 'Dịch kịch tính, sến sẫm.'},
        'tieu_lam': {'name': 'Tiểu Lâm', 'icon': '😂', 'prompt': 'Dịch đời thường, hài hước.'},
        'co_trang': {'name': 'Cổ Trang / Kiếm Hiệp', 'icon': '⚔️', 'prompt': 'Dịch thơ mộng, kiếm hiệp.'},
        'tam_trang': {'name': 'Tâm Trạng / Triết Lý', 'icon': '💜', 'prompt': 'Dịch sâu lắng, chữa lành.'},
        'khoa_hoc': {'name': 'Khoa học / Kỹ thuật', 'icon': '🔬', 'prompt': 'Dịch chính xác, dễ hiểu.'},
        'hanh_dong': {'name': 'Hành động / Kịch tính', 'icon': '💥', 'prompt': 'Dịch nhanh, mạnh, súc tích.'},
        'capcut': {'name': 'Dịch phụ đề Capcut', 'icon': '🎯', 'prompt': 'Dịch ngắn gọn, dễ đọc.'}
    }
    
    SUBTITLE_FORMATS = ['SRT', 'WebVTT', 'ASS', 'TXT', 'JSON', 'CSV', 'LRC']

# ==================== INIT APP ====================
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['MAX_CONTENT_LENGTH'] = Config.MAX_FILE_SIZE
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Create folders
for folder in [Config.VIDEO_FOLDER, Config.AUDIO_FOLDER, 
               Config.SUBTITLE_FOLDER, Config.EXPORT_FOLDER, 
               Config.PRESET_FOLDER, Config.UPLOAD_FOLDER]:
    os.makedirs(folder, exist_ok=True)

# ==================== GLOBAL STATE ====================
settings = {
    'gemini_api_key': '',
    'groq_api_key': '',
    'target_lang': 'vi',
    'style': 'default',
    'voice': 'BV074_streaming',
    'provider': 'gemini',
    'resolution': '1080p',
    'mode': 'auto'
}

subtitle_settings = {
    'enabled': True, 'font': 'Oswald', 'font_size': 60, 'color': '#FFFFFF',
    'bg_color': '#000000', 'bg_opacity': 50, 'bg_type': 'Hộp đục',
    'bold': False, 'italic': False, 'underline': False,
    'position': 'bottom', 'show_on_player': True
}

crop_settings = {
    'enabled': False, 'x': 0, 'y': 70, 'w': 100, 'h': 30,
    'color': 'rgba(102, 126, 234, 0.3)', 'border_color': '#667eea'
}

blur_settings = {
    'enabled': False, 'mode': 'Mặc định', 'blur_type': 'Gaussian Blur',
    'subtitle_on_blur': False,
    'regions': [
        {'id': 1, 'enabled': False, 'name': 'Vùng 1', 'x': 0, 'y': 0, 'w': 100, 'h': 20, 'intensity': 15, 'color': '#000000'},
        {'id': 2, 'enabled': False, 'name': 'Vùng 2', 'x': 0, 'y': 80, 'w': 100, 'h': 20, 'intensity': 15, 'color': '#000000'},
        {'id': 3, 'enabled': False, 'name': 'Vùng 3', 'x': 0, 'y': 0, 'w': 20, 'h': 100, 'intensity': 15, 'color': '#000000'},
        {'id': 4, 'enabled': False, 'name': 'Vùng 4', 'x': 80, 'y': 0, 'w': 20, 'h': 100, 'intensity': 15, 'color': '#000000'}
    ]
}

logo_settings = {
    'enabled': False, 'type': 'text', 'text': 'GenSubAI',
    'font': 'Arial', 'font_size': 24, 'color': '#FFFFFF',
    'stroke_color': '#000000', 'position': 'Góc trên - Trái',
    'opacity': 100, 'image_path': None
}

voice_settings = {
    'G1': {'name': 'Giọng nam phổ thông', 'voice_id': 'BV075_streaming', 'speed': 1.0},
    'G2': {'name': 'Giọng nữ phổ thông', 'voice_id': 'vi_female_huong', 'speed': 1.0},
    'G3': {'name': 'Giọng nam trung niên', 'voice_id': 'vi-VN-NamMinhNeural', 'speed': 1.0}
}

presets = []
uploaded_videos = []
uploaded_files = []
extraction_stats = {
    'total_subtitles': 0, 'avg_cps': 0, 'total_duration': 0,
    'total_chars': 0, 'language': 'unknown', 'method': 'unknown'
}

current_project = {
    'video': None, 'subtitles': [], 'translated': [], 'audio_files': [],
    'stats': extraction_stats.copy(),
    'settings': {
        'subtitle': subtitle_settings.copy(),
        'crop': crop_settings.copy(),
        'blur': blur_settings.copy(),
        'logo': logo_settings.copy(),
        'voice': voice_settings.copy()
    }
}

# ==================== LOAD PRESETS ====================
def load_presets():
    global presets
    preset_file = os.path.join(Config.PRESET_FOLDER, 'presets.json')
    if os.path.exists(preset_file):
        try:
            with open(preset_file, 'r', encoding='utf-8') as f:
                presets = json.load(f)
        except:
            presets = []

def save_presets():
    preset_file = os.path.join(Config.PRESET_FOLDER, 'presets.json')
    with open(preset_file, 'w', encoding='utf-8') as f:
        json.dump(presets, f, ensure_ascii=False, indent=2)

load_presets()

# ==================== HELPER FUNCTIONS ====================
def allowed_file(filename, allowed_extensions=None):
    if allowed_extensions is None:
        allowed_extensions = Config.ALLOWED_EXTENSIONS
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

def get_file_extension(filename):
    return filename.rsplit('.', 1)[1].lower() if '.' in filename else ''

def format_time(seconds):
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int((seconds % 1) * 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def format_time_ass(seconds):
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    cs = int((seconds % 1) * 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

def parse_srt_time(time_str):
    import re
    pattern = r'(\d{2}):(\d{2}):(\d{2}),(\d{3})'
    match = re.match(pattern, time_str.strip())
    if match:
        h, m, s, ms = map(int, match.groups())
        return h * 3600 + m * 60 + s + ms / 1000
    return 0

def parse_vtt_time(time_str):
    import re
    pattern = r'(\d{2}):(\d{2}):(\d{2})\.(\d{3})'
    match = re.match(pattern, time_str.strip())
    if match:
        h, m, s, ms = map(int, match.groups())
        return h * 3600 + m * 60 + s + ms / 1000
    return 0

# ==================== SERVICES ====================

# ---------- 1. VIDEO DOWNLOADER ----------
class VideoDownloader:
    def __init__(self):
        self.resolutions = {
            '2160p': 'bestvideo[height<=2160]+bestaudio/best[height<=2160]',
            '1440p': 'bestvideo[height<=1440]+bestaudio/best[height<=1440]',
            '1080p': 'bestvideo[height<=1080]+bestaudio/best[height<=1080]',
            '720p': 'bestvideo[height<=720]+bestaudio/best[height<=720]',
            '480p': 'bestvideo[height<=480]+bestaudio/best[height<=480]',
            '360p': 'bestvideo[height<=360]+bestaudio/best[height<=360]'
        }
    
    def download_video(self, url, resolution='1080p'):
        try:
            import yt_dlp
            output_path = Config.VIDEO_FOLDER
            os.makedirs(output_path, exist_ok=True)
            
            ydl_opts = {
                'format': self.resolutions.get(resolution, 'bestvideo[height<=1080]+bestaudio/best[height<=1080]'),
                'outtmpl': os.path.join(output_path, '%(title)s.%(ext)s'),
                'quiet': True,
                'merge_output_format': 'mp4'
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                filename = ydl.prepare_filename(info)
                
                video_info = {
                    'id': str(uuid.uuid4())[:8],
                    'name': info.get('title'),
                    'path': filename,
                    'duration': info.get('duration'),
                    'size': os.path.getsize(filename) if os.path.exists(filename) else 0,
                    'uploaded_at': datetime.now().strftime('%Y-%m-%d %H:%M')
                }
                uploaded_videos.append(video_info)
                current_project['video'] = video_info
                return {'success': True, 'video': video_info}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# ---------- 2. SUBTITLE EXTRACTOR ----------
class SubtitleExtractor:
    def extract_from_ocr(self, video_path, language='vie+eng', crop_region=None):
        try:
            import cv2
            import pytesseract
            
            if not os.path.exists(video_path):
                return {'success': False, 'error': 'Video không tồn tại'}
            
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                return {'success': False, 'error': 'Không thể mở video'}
            
            fps = cap.get(cv2.CAP_PROP_FPS)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            video_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            video_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            
            crop_enabled = crop_region and crop_region.get('enabled', False)
            if crop_enabled:
                x_pct = crop_region.get('x', 0) / 100
                y_pct = crop_region.get('y', 70) / 100
                w_pct = crop_region.get('w', 100) / 100
                h_pct = crop_region.get('h', 30) / 100
                crop_x = int(x_pct * video_width)
                crop_y = int(y_pct * video_height)
                crop_w = int(w_pct * video_width)
                crop_h = int(h_pct * video_height)
            else:
                crop_x, crop_y, crop_w, crop_h = 0, 0, video_width, video_height
            
            subtitles = []
            frame_count = 0
            prev_text = ""
            total_chars = 0
            
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break
                
                if frame_count % 30 == 0:
                    if crop_enabled:
                        frame_roi = frame[crop_y:crop_y+crop_h, crop_x:crop_x+crop_w]
                    else:
                        frame_roi = frame
                    
                    gray = cv2.cvtColor(frame_roi, cv2.COLOR_BGR2GRAY)
                    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                    text = pytesseract.image_to_string(thresh, lang=language).strip()
                    
                    if text and text != prev_text:
                        start_time = frame_count / fps
                        end_time = (frame_count + 30) / fps
                        duration = end_time - start_time
                        cps = len(text) / duration if duration > 0 else 0
                        total_chars += len(text)
                        
                        subtitles.append({
                            'index': len(subtitles) + 1,
                            'start': round(start_time, 3),
                            'end': round(end_time, 3),
                            'duration': round(duration, 3),
                            'text': text,
                            'translated': '',
                            'voice': 'G1',
                            'speed': 1.0,
                            'cps': round(cps, 1),
                            'char_count': len(text)
                        })
                        prev_text = text
                    
                    progress = int((frame_count / total_frames) * 100) if total_frames > 0 else 0
                    socketio.emit('progress', {
                        'stage': 'extracting',
                        'progress': progress,
                        'message': f'Đang trích xuất... {progress}% ({len(subtitles)} dòng)',
                        'subtitles_found': len(subtitles)
                    })
                
                frame_count += 1
            
            cap.release()
            
            total_duration = sum(s.get('duration', 0) for s in subtitles)
            avg_cps = total_chars / total_duration if total_duration > 0 else 0
            
            stats = {
                'total_subtitles': len(subtitles),
                'avg_cps': round(avg_cps, 1),
                'total_duration': round(total_duration, 1),
                'total_chars': total_chars,
                'language': language,
                'method': 'OCR'
            }
            
            return {'success': True, 'subtitles': subtitles, 'stats': stats}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def extract_from_audio(self, audio_path, language='vi-VN'):
        try:
            import speech_recognition as sr
            
            if not os.path.exists(audio_path):
                return {'success': False, 'error': 'Audio không tồn tại'}
            
            recognizer = sr.Recognizer()
            
            with sr.AudioFile(audio_path) as source:
                audio = recognizer.record(source)
                text = recognizer.recognize_google(audio, language=language)
                
                sentences = re.split(r'[.!?]+', text)
                sentences = [s.strip() for s in sentences if s.strip()]
                
                subtitles = []
                total_chars = 0
                duration_per_sentence = 3.0
                
                for i, sentence in enumerate(sentences):
                    subtitles.append({
                        'index': i + 1,
                        'start': round(i * duration_per_sentence, 3),
                        'end': round((i + 1) * duration_per_sentence, 3),
                        'duration': duration_per_sentence,
                        'text': sentence,
                        'translated': '',
                        'voice': 'G1',
                        'speed': 1.0,
                        'cps': round(len(sentence) / duration_per_sentence, 1),
                        'char_count': len(sentence)
                    })
                    total_chars += len(sentence)
                
                stats = {
                    'total_subtitles': len(subtitles),
                    'avg_cps': round(total_chars / (len(subtitles) * duration_per_sentence), 1) if subtitles else 0,
                    'total_duration': round(len(subtitles) * duration_per_sentence, 1),
                    'total_chars': total_chars,
                    'language': language,
                    'method': 'STT'
                }
                
                return {'success': True, 'subtitles': subtitles, 'stats': stats}
        except Exception as e:
            return {'success': False, 'error': str(e)}

# ---------- 3. SUBTITLE PARSER ----------
class SubtitleParser:
    @staticmethod
    def parse_srt(file_path):
        subtitles = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            i = 0
            while i < len(lines):
                if not lines[i].strip():
                    i += 1
                    continue
                
                if lines[i].strip().isdigit():
                    idx = int(lines[i].strip())
                    i += 1
                else:
                    idx = len(subtitles) + 1
                
                if i < len(lines) and '-->' in lines[i]:
                    time_line = lines[i].strip()
                    start_str, end_str = time_line.split('-->')
                    start = parse_srt_time(start_str)
                    end = parse_srt_time(end_str)
                    i += 1
                else:
                    start = len(subtitles) * 3
                    end = start + 3
                
                text_lines = []
                while i < len(lines) and lines[i].strip():
                    text_lines.append(lines[i].strip())
                    i += 1
                
                text = ' '.join(text_lines)
                if text:
                    subtitles.append({
                        'index': idx,
                        'start': start,
                        'end': end,
                        'duration': end - start,
                        'text': text,
                        'translated': '',
                        'voice': 'G1',
                        'speed': 1.0
                    })
                
                i += 1
            
            return {'success': True, 'subtitles': subtitles}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    @staticmethod
    def parse_vtt(file_path):
        subtitles = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            start_idx = 0
            for i, line in enumerate(lines):
                if '-->' in line:
                    start_idx = i
                    break
            
            i = start_idx
            while i < len(lines):
                if not lines[i].strip():
                    i += 1
                    continue
                
                if '-->' in lines[i]:
                    time_line = lines[i].strip()
                    start_str, end_str = time_line.split('-->')
                    start = parse_vtt_time(start_str.strip())
                    end = parse_vtt_time(end_str.strip())
                    i += 1
                    
                    text_lines = []
                    while i < len(lines) and lines[i].strip():
                        text_lines.append(lines[i].strip())
                        i += 1
                    
                    text = ' '.join(text_lines)
                    if text:
                        subtitles.append({
                            'index': len(subtitles) + 1,
                            'start': start,
                            'end': end,
                            'duration': end - start,
                            'text': text,
                            'translated': '',
                            'voice': 'G1',
                            'speed': 1.0
                        })
                else:
                    i += 1
            
            return {'success': True, 'subtitles': subtitles}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    @staticmethod
    def export_srt(subtitles, output_path):
        with open(output_path, 'w', encoding='utf-8') as f:
            for sub in subtitles:
                start = format_time(sub.get('start', 0))
                end = format_time(sub.get('end', sub.get('start', 0) + 3))
                text = sub.get('translated', sub.get('text', ''))
                f.write(f"{sub.get('index', 0)}\n{start} --> {end}\n{text}\n\n")
        return output_path

# ---------- 4. TRANSLATION SERVICE ----------
class TranslationService:
    def __init__(self):
        self.gemini_api_key = settings.get('gemini_api_key', '')
        self.groq_api_key = settings.get('groq_api_key', '')
    
    def translate(self, text, style='default', target_lang='vi', provider='gemini'):
        if not text or not text.strip():
            return text
        
        style_config = Config.TRANSLATION_STYLES.get(style, Config.TRANSLATION_STYLES['default'])
        
        if provider == 'gemini':
            return self._translate_gemini(text, style_config, target_lang)
        elif provider == 'groq':
            return self._translate_groq(text, style_config, target_lang)
        return text
    
    def _translate_gemini(self, text, style_config, target_lang):
        try:
            import google.generativeai as genai
            if not self.gemini_api_key:
                return text
            genai.configure(api_key=self.gemini_api_key)
            model = genai.GenerativeModel('gemini-pro')
            prompt = f"""
            {style_config['prompt']}
            Dịch sang tiếng {target_lang}: "{text}"
            Chỉ trả về bản dịch.
            """
            response = model.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            return f"[Lỗi Gemini] {text}"
    
    def _translate_groq(self, text, style_config, target_lang):
        try:
            from groq import Groq
            if not self.groq_api_key:
                return text
            client = Groq(api_key=self.groq_api_key)
            response = client.chat.completions.create(
                model="mixtral-8x7b-32768",
                messages=[
                    {"role": "system", "content": style_config['prompt']},
                    {"role": "user", "content": f"Dịch sang tiếng {target_lang}: {text}"}
                ],
                temperature=0.3,
                max_tokens=1024
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"[Lỗi Groq] {text}"
    
    def batch_translate(self, subtitles, style='default', target_lang='vi', provider='gemini'):
        results = []
        total = len(subtitles)
        for i, sub in enumerate(subtitles):
            text = sub.get('text', '')
            translated = self.translate(text, style, target_lang, provider)
            results.append({**sub, 'translated': translated})
            progress = int((i + 1) / total * 100) if total > 0 else 100
            socketio.emit('progress', {
                'stage': 'translating',
                'progress': progress,
                'message': f'Đang dịch {i+1}/{total}'
            })
        return results

# ---------- 5. TTS SERVICE ----------
class TTSService:
    def __init__(self):
        self.voices = self._load_voices()
        self.audio_folder = Config.AUDIO_FOLDER
        os.makedirs(self.audio_folder, exist_ok=True)
    
    def _load_voices(self):
        voice_file = 'Voice.json'
        if os.path.exists(voice_file):
            try:
                with open(voice_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def get_voices(self, language=None):
        if language:
            return [v for v in self.voices if v.get('lan') == language]
        return self.voices
    
    def get_voice_by_id(self, voice_id):
        for v in self.voices:
            if v.get('voice_type') == voice_id:
                return v
        return None
    
    def generate_speech(self, text, voice_id='BV074_streaming', rate=1.0, output_file=None):
        if not output_file:
            output_file = os.path.join(self.audio_folder, f"tts_{uuid.uuid4().hex[:8]}.mp3")
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(f"TTS: {text[:50]}")
        
        return {
            'success': True,
            'audio_path': output_file,
            'duration': len(text) * 0.08,
            'text': text,
            'voice_id': voice_id
        }
    
    def batch_generate(self, subtitles, voice_id='BV074_streaming', rate=1.0):
        results = []
        total_duration = 0
        total = len(subtitles)
        
        for i, sub in enumerate(subtitles):
            text = sub.get('translated') or sub.get('text', '')
            if not text.strip():
                continue
            
            voice = sub.get('voice', voice_id)
            output_file = os.path.join(self.audio_folder, f"tts_{uuid.uuid4().hex[:8]}_{i}.mp3")
            result = self.generate_speech(text, voice, rate, output_file)
            
            if result['success']:
                results.append({
                    'index': sub.get('index', i),
                    'text': text,
                    'audio_path': result['audio_path'],
                    'duration': result['duration'],
                    'voice': voice
                })
                total_duration += result['duration']
            
            progress = int((i + 1) / total * 100) if total > 0 else 100
            socketio.emit('progress', {
                'stage': 'tts',
                'progress': progress,
                'message': f'Đang tạo giọng {i+1}/{total}'
            })
        
        return {'success': True, 'audio_files': results, 'total_duration': total_duration}

# ==================== SOCKET EVENTS ====================

@socketio.on('connect')
def handle_connect():
    emit('connected', {'status': 'OK'})

@socketio.on('get_settings')
def handle_get_settings():
    emit('settings', settings)

@socketio.on('save_settings')
def handle_save_settings(data):
    global settings
    for key in data:
        if key in settings:
            settings[key] = data[key]
    emit('settings_saved', {'success': True, 'settings': settings})

@socketio.on('download_video')
def handle_download_video(data):
    def process():
        try:
            emit('progress', {'stage': 'downloading', 'progress': 0, 'message': 'Đang tải video...'})
            downloader = VideoDownloader()
            result = downloader.download_video(
                url=data['url'],
                resolution=data.get('resolution', settings.get('resolution', '1080p'))
            )
            if result['success']:
                emit('progress', {
                    'stage': 'done',
                    'progress': 100,
                    'message': 'Tải video thành công!',
                    'data': {'video': result['video']}
                })
            else:
                emit('error', {'message': result.get('error', 'Tải video thất bại')})
        except Exception as e:
            emit('error', {'message': str(e)})
    threading.Thread(target=process).start()

@socketio.on('get_videos')
def handle_get_videos():
    emit('videos_list', {'videos': uploaded_videos})

@socketio.on('delete_video')
def handle_delete_video(data):
    global uploaded_videos
    video_id = data.get('id')
    uploaded_videos = [v for v in uploaded_videos if v.get('id') != video_id]
    emit('videos_list', {'videos': uploaded_videos})

@socketio.on('extract_subtitles')
def handle_extract_subtitles(data):
    def process():
        try:
            video_path = data.get('video_path')
            if not video_path:
                emit('error', {'message': 'Chưa có video'})
                return
            
            if not os.path.exists(video_path):
                emit('error', {'message': 'File video không tồn tại'})
                return
            
            extractor = SubtitleExtractor()
            method = data.get('method', 'ocr')
            language = data.get('language', 'vie+eng')
            crop_region = data.get('crop_region', crop_settings)
            
            if method == 'ocr':
                result = extractor.extract_from_ocr(video_path, language, crop_region)
            else:
                audio_path = data.get('audio_path')
                if not audio_path:
                    emit('error', {'message': 'Cần file audio cho STT'})
                    return
                result = extractor.extract_from_audio(audio_path, language)
            
            if result['success']:
                current_project['subtitles'] = result['subtitles']
                current_project['stats'] = result.get('stats', {})
                emit('progress', {
                    'stage': 'extracted',
                    'progress': 100,
                    'message': f'✅ Trích xuất thành công! Tìm thấy {len(result["subtitles"])} dòng phụ đề',
                    'data': {'subtitles': result['subtitles'], 'stats': result.get('stats', {})}
                })
                emit('subtitle_stats', result.get('stats', {}))
            else:
                emit('error', {'message': result.get('error', 'Trích xuất thất bại')})
        except Exception as e:
            emit('error', {'message': str(e)})
    threading.Thread(target=process).start()

@socketio.on('translate_subtitles')
def handle_translate_subtitles(data):
    def process():
        try:
            subtitles = data.get('subtitles', current_project.get('subtitles', []))
            if not subtitles:
                emit('error', {'message': 'Chưa có phụ đề để dịch'})
                return
            
            translator = TranslationService()
            style = data.get('style', settings.get('style', 'default'))
            target = data.get('target_lang', settings.get('target_lang', 'vi'))
            provider = data.get('provider', settings.get('provider', 'gemini'))
            
            translated = translator.batch_translate(subtitles, style, target, provider)
            current_project['translated'] = translated
            
            emit('progress', {
                'stage': 'done',
                'progress': 100,
                'message': f'✅ Dịch thành công! Đã dịch {len(translated)} dòng',
                'data': {'subtitles': translated}
            })
        except Exception as e:
            emit('error', {'message': str(e)})
    threading.Thread(target=process).start()

@socketio.on('generate_tts')
def handle_generate_tts(data):
    def process():
        try:
            subtitles = data.get('subtitles', current_project.get('translated', []))
            if not subtitles:
                emit('error', {'message': 'Chưa có phụ đề để tạo giọng đọc'})
                return
            
            tts = TTSService()
            voice_id = data.get('voice', settings.get('voice', 'BV074_streaming'))
            rate = data.get('rate', 1.0)
            
            result = tts.batch_generate(subtitles, voice_id, rate)
            if result['success']:
                current_project['audio_files'] = result['audio_files']
                emit('progress', {
                    'stage': 'done',
                    'progress': 100,
                    'message': f'✅ Tạo giọng đọc thành công! {len(result["audio_files"])} file',
                    'data': result
                })
            else:
                emit('error', {'message': result.get('error', 'Tạo giọng đọc thất bại')})
        except Exception as e:
            emit('error', {'message': str(e)})
    threading.Thread(target=process).start()

@socketio.on('get_voices')
def handle_get_voices(data):
    tts = TTSService()
    voices = tts.get_voices(data.get('language'))
    emit('voices_list', {'voices': voices})

@socketio.on('get_crop_settings')
def handle_get_crop_settings():
    emit('crop_settings', crop_settings)

@socketio.on('save_crop_settings')
def handle_save_crop_settings(data):
    global crop_settings
    for key in data:
        if key in crop_settings:
            crop_settings[key] = data[key]
    current_project['settings']['crop'] = crop_settings.copy()
    emit('crop_settings_saved', {'success': True, 'settings': crop_settings})

@socketio.on('get_blur_settings')
def handle_get_blur_settings():
    emit('blur_settings', blur_settings)

@socketio.on('save_blur_settings')
def handle_save_blur_settings(data):
    global blur_settings
    for key in data:
        if key in blur_settings:
            blur_settings[key] = data[key]
        elif key == 'regions':
            blur_settings['regions'] = data['regions']
    current_project['settings']['blur'] = blur_settings.copy()
    emit('blur_settings_saved', {'success': True, 'settings': blur_settings})

@socketio.on('update_blur_region')
def handle_update_blur_region(data):
    global blur_settings
    region_id = data.get('id')
    for region in blur_settings['regions']:
        if region['id'] == region_id:
            for key in data:
                if key in region:
                    region[key] = data[key]
            break
    current_project['settings']['blur'] = blur_settings.copy()
    emit('blur_region_updated', {'success': True, 'regions': blur_settings['regions']})

@socketio.on('get_subtitle_settings')
def handle_get_subtitle_settings():
    emit('subtitle_settings', subtitle_settings)

@socketio.on('save_subtitle_settings')
def handle_save_subtitle_settings(data):
    global subtitle_settings
    for key in data:
        if key in subtitle_settings:
            subtitle_settings[key] = data[key]
    current_project['settings']['subtitle'] = subtitle_settings.copy()
    emit('subtitle_settings_saved', {'success': True, 'settings': subtitle_settings})

@socketio.on('get_logo_settings')
def handle_get_logo_settings():
    emit('logo_settings', logo_settings)

@socketio.on('save_logo_settings')
def handle_save_logo_settings(data):
    global logo_settings
    for key in data:
        if key in logo_settings:
            logo_settings[key] = data[key]
    current_project['settings']['logo'] = logo_settings.copy()
    emit('logo_settings_saved', {'success': True, 'settings': logo_settings})

@socketio.on('get_voice_settings')
def handle_get_voice_settings():
    emit('voice_settings', voice_settings)

@socketio.on('save_voice_settings')
def handle_save_voice_settings(data):
    global voice_settings
    for key in data:
        if key in voice_settings:
            voice_settings[key] = data[key]
    current_project['settings']['voice'] = voice_settings.copy()
    emit('voice_settings_saved', {'success': True, 'settings': voice_settings})

@socketio.on('get_presets')
def handle_get_presets():
    emit('presets_list', {'presets': presets})

@socketio.on('save_preset')
def handle_save_preset(data):
    global presets
    preset = {
        'id': str(uuid.uuid4())[:8],
        'name': data.get('name', 'Preset'),
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'settings': {
            'subtitle': subtitle_settings.copy(),
            'crop': crop_settings.copy(),
            'blur': blur_settings.copy(),
            'logo': logo_settings.copy(),
            'voice': voice_settings.copy()
        }
    }
    presets.append(preset)
    save_presets()
    emit('preset_saved', {'success': True, 'preset': preset})

@socketio.on('load_preset')
def handle_load_preset(data):
    global subtitle_settings, crop_settings, blur_settings, logo_settings, voice_settings
    preset_id = data.get('id')
    for preset in presets:
        if preset.get('id') == preset_id:
            settings_data = preset.get('settings', {})
            if 'subtitle' in settings_data:
                subtitle_settings.update(settings_data['subtitle'])
            if 'crop' in settings_data:
                crop_settings.update(settings_data['crop'])
            if 'blur' in settings_data:
                blur_settings.update(settings_data['blur'])
            if 'logo' in settings_data:
                logo_settings.update(settings_data['logo'])
            if 'voice' in settings_data:
                voice_settings.update(settings_data['voice'])
            emit('preset_loaded', {'success': True, 'settings': settings_data})
            break

@socketio.on('delete_preset')
def handle_delete_preset(data):
    global presets
    preset_id = data.get('id')
    presets = [p for p in presets if p.get('id') != preset_id]
    save_presets()
    emit('preset_deleted', {'success': True})

@socketio.on('update_subtitle')
def handle_update_subtitle(data):
    index = data.get('index')
    field = data.get('field')
    value = data.get('value')
    
    subtitles = current_project.get('translated', current_project.get('subtitles', []))
    for sub in subtitles:
        if sub.get('index') == index:
            sub[field] = value
            break
    
    current_project['translated'] = subtitles
    emit('subtitle_updated', {'success': True, 'index': index, 'field': field, 'value': value})

@socketio.on('export_subtitles')
def handle_export_subtitles(data):
    format_type = data.get('format', 'SRT')
    subtitles = data.get('subtitles', current_project.get('translated', []))
    
    if not subtitles:
        emit('error', {'message': 'Chưa có phụ đề để xuất'})
        return
    
    output_file = os.path.join(Config.SUBTITLE_FOLDER, f"subtitles_{uuid.uuid4().hex[:8]}.{format_type.lower()}")
    
    if format_type == 'SRT':
        content = ''
        for sub in subtitles:
            start = format_time(sub.get('start', 0))
            end = format_time(sub.get('end', sub.get('start', 0) + 3))
            text = sub.get('translated', sub.get('text', ''))
            content += f"{sub.get('index', 0)}\n{start} --> {end}\n{text}\n\n"
    elif format_type == 'ASS':
        content = '[Script Info]\nTitle: Subtitles\n\n[Events]\nFormat: Layer, Start, End, Text\n'
        for sub in subtitles:
            start = format_time_ass(sub.get('start', 0))
            end = format_time_ass(sub.get('end', sub.get('start', 0) + 3))
            text = sub.get('translated', sub.get('text', ''))
            content += f"Dialogue: 0,{start},{end},{text}\n"
    elif format_type == 'JSON':
        content = json.dumps(subtitles, ensure_ascii=False, indent=2)
    else:
        content = '\n'.join([sub.get('translated', sub.get('text', '')) for sub in subtitles])
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    emit('export_done', {'success': True, 'file_path': output_file, 'format': format_type})

# ==================== ROUTES ====================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/editor')
def editor():
    return render_template('editor.html')

@app.route('/upload')
def upload():
    return render_template('upload.html', languages=Config.LANGUAGES)

@app.route('/upload_subtitle')
def upload_subtitle():
    return render_template('upload_subtitle.html', languages=Config.LANGUAGES, styles=Config.TRANSLATION_STYLES)

# ==================== API ROUTES ====================

@app.route('/api/styles')
def get_styles():
    return jsonify(Config.TRANSLATION_STYLES)

@app.route('/api/languages')
def get_languages():
    return jsonify(Config.LANGUAGES)

@app.route('/api/export/<filename>')
def download_export(filename):
    filepath = os.path.join(Config.EXPORT_FOLDER, filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

@app.route('/api/subtitle/<filename>')
def download_subtitle(filename):
    filepath = os.path.join(Config.SUBTITLE_FOLDER, filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

@app.route('/download/<filename>')
def download_file(filename):
    filepath = os.path.join(Config.SUBTITLE_FOLDER, filename)
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return jsonify({'error': 'File not found'}), 404

# ---------- Upload File (Video/Audio) ----------
@app.route('/upload_file', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'Không có file'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Chưa chọn file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Định dạng file không hỗ trợ'}), 400
    
    filename = secure_filename(file.filename)
    unique_filename = f"{uuid.uuid4().hex[:8]}_{filename}"
    filepath = os.path.join(Config.UPLOAD_FOLDER, unique_filename)
    file.save(filepath)
    
    file_info = {
        'id': str(uuid.uuid4())[:8],
        'name': filename,
        'path': filepath,
        'size': os.path.getsize(filepath),
        'uploaded_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'type': 'video' if get_file_extension(filename) in Config.ALLOWED_VIDEO_EXT else 'audio'
    }
    uploaded_files.append(file_info)
    
    return jsonify({'success': True, 'file': file_info})

# ---------- Extract from File ----------
@app.route('/api/extract_from_file', methods=['POST'])
def extract_from_file():
    data = request.json
    file_id = data.get('file_id')
    language = data.get('language', 'vie+eng')
    
    if not file_id:
        return jsonify({'error': 'Chưa có file'}), 400
    
    file_info = None
    for f in uploaded_files:
        if f.get('id') == file_id:
            file_info = f
            break
    
    if not file_info:
        return jsonify({'error': 'File không tồn tại'}), 404
    
    filepath = file_info.get('path')
    file_type = file_info.get('type')
    
    extractor = SubtitleExtractor()
    
    if file_type == 'video':
        result = extractor.extract_from_ocr(filepath, language, crop_settings)
    else:
        result = extractor.extract_from_audio(filepath, language)
    
    if result['success']:
        current_project['subtitles'] = result['subtitles']
        return jsonify({
            'success': True,
            'subtitles': result['subtitles'],
            'stats': result.get('stats', {})
        })
    else:
        return jsonify({'error': result.get('error', 'Trích xuất thất bại')}), 500

# ---------- Upload Subtitle ----------
@app.route('/upload_subtitle_file', methods=['POST'])
def upload_subtitle_file():
    if 'file' not in request.files:
        return jsonify({'error': 'Không có file'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Chưa chọn file'}), 400
    
    ext = get_file_extension(file.filename)
    if ext not in Config.ALLOWED_SUBTITLE_EXT:
        return jsonify({'error': f'Định dạng {ext} không hỗ trợ'}), 400
    
    filename = secure_filename(file.filename)
    unique_filename = f"{uuid.uuid4().hex[:8]}_{filename}"
    filepath = os.path.join(Config.SUBTITLE_FOLDER, unique_filename)
    file.save(filepath)
    
    parser = SubtitleParser()
    if ext == 'srt':
        result = parser.parse_srt(filepath)
    else:
        result = parser.parse_vtt(filepath)
    
    if result['success']:
        current_project['subtitles'] = result['subtitles']
        return jsonify({
            'success': True,
            'subtitles': result['subtitles'],
            'file_path': filepath,
            'filename': filename
        })
    else:
        return jsonify({'error': result.get('error', 'Đọc file thất bại')}), 500

# ---------- Translate Subtitle File ----------
@app.route('/api/translate_subtitle_file', methods=['POST'])
def translate_subtitle_file():
    data = request.json
    file_path = data.get('file_path')
    target_lang = data.get('target_lang', 'vi')
    style = data.get('style', 'default')
    provider = data.get('provider', 'gemini')
    
    if not file_path or not os.path.exists(file_path):
        return jsonify({'error': 'File không tồn tại'}), 404
    
    ext = get_file_extension(file_path)
    parser = SubtitleParser()
    
    if ext == 'srt':
        result = parser.parse_srt(file_path)
    elif ext == 'vtt':
        result = parser.parse_vtt(file_path)
    else:
        return jsonify({'error': 'Định dạng không hỗ trợ'}), 400
    
    if not result['success']:
        return jsonify({'error': result.get('error', 'Đọc file thất bại')}), 500
    
    subtitles = result['subtitles']
    
    translator = TranslationService()
    translated = translator.batch_translate(subtitles, style, target_lang, provider)
    
    output_filename = f"translated_{uuid.uuid4().hex[:8]}.srt"
    output_path = os.path.join(Config.SUBTITLE_FOLDER, output_filename)
    parser.export_srt(translated, output_path)
    
    return jsonify({
        'success': True,
        'subtitles': translated,
        'output_path': output_path,
        'output_filename': output_filename
    })

# ==================== RUN ====================

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)